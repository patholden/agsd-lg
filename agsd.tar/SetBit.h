#include <stdint.h>
#ifndef SETBIT
#define SETBIT  1

void DoSetBit(struct lg_master *pLgMaster, struct parse_setbit_parms *pInp, uint32_t respondToWhom);

#endif
