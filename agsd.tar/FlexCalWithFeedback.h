#ifndef FLEXCALWITHFEEDBACK_H
#define FLEXCALWITHFEEDBACK_H

void FlexCalWithFeedback(struct lg_master *pLgMaster, struct parse_flexcalxfdbk_parms *pInp, uint32_t respondToWhom);

#endif
