#include <stdint.h>
#ifndef ALLACE4_H
#define ALLACE4_H

extern
double
allace4( double *xin, double *yin )
;

#endif
