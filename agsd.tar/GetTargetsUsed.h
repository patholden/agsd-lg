#ifndef TGTSUSED_H
#define TGTSUSED_H

void GetTargetsUsed(struct lg_master *pLgMaster, uint32_t respondToWhom);

#endif  // TGTSUSED_H
