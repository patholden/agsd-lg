#include <stdint.h>
void PerformAndSendFlexReg ( int LDflag,
                             char * data,
                             uint32_t respondToWhom );

