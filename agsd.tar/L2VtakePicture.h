#ifndef L2VTAKEPICTURE_H
#define L2VTAKEPICTURE_H

extern
void L2VtakePicture ( struct lg_master *pLgMaster,
                     struct parse_takepic_parms * pInp,
                     uint32_t respondToWhom)
;

#endif
