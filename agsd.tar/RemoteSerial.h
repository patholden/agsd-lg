
#ifndef REMOTESERIAL_H
#define REMOTESERIAL_H

extern
void RemoteSerial ( struct lg_master *pLgMaster, char * buffer );

#endif
