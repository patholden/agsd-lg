extern void DoRefreshRate (struct lg_master *pLgMaster, uint32_t respondToWhom );
