#ifndef DOCOARSESCAN2_H
#define DOCOARSESCAN2_H

int DoCoarseScan2(struct lg_master *pLgMaster, int16_t dX, int16_t dY,
		  uint16_t lsstep, uint16_t lscount, int16_t *xfound,
		  int16_t *yfound);


#endif
