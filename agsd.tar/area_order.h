#ifndef AREAORDER_H
#define AREAORDER_H

void area_order(struct lg_master *pLgMaster, int numin, doubleInputPoint *inPt, int *num_out,
	      permutes *Combos, int32_t *reversedex, int32_t *found);

#endif  // AREAORDER_H
