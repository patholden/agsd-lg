#ifndef PARSEVISF_H
#define PARSEVISF_H

int ParseVisionFocus(int length, char * infile);

#endif  // PARSEVISF_H
