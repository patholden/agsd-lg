#ifndef PARSEVISION_H
#define PARSEVISION_H

extern
int
ParseVision( struct lg_master *pLgMaster
          , unsigned char * in_buff
          , int size
          )
;

#endif
