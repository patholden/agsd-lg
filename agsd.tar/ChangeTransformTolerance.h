#include <stdint.h>
#ifndef CHANGETRANSFORMTOLERANCE_H
#define CHANGETRANSFORMTOLERANCE_H

extern
void DoChangeTransformTolerance(struct lg_master *pLgMaster, struct parse_chngxfrmtol_parms *pInp);

#endif
