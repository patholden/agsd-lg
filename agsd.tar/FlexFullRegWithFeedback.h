extern void FlexFullRegWithFeedback ( struct lg_master *pLgMaster,
				      char * parameters,
				      uint32_t respondToWhom );
