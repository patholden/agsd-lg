#ifndef NET_H
#define NET_H
/* "$Id" */

int OpenNet (struct lg_master *pLgMaster);
int GetNetVideo(char *inbuff, int incount, char *outbuff);

#endif // END_H
