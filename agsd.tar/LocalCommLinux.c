#include <stdint.h>
static char rcsid[] = "$Id: LocalCommLinux.c,v 1.2 1997/05/11 23:23:55 ags-sw Exp $";

#include "AppCommon.h"

unsigned char gLocalMode = false;

void SaveResponse ( char * theResponse, int32_t length )
{
	return;
}
