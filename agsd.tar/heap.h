#ifndef  HEAP_H
#define HEAP_H
void heap( int32_t n, double *arr, int32_t *indx );
#endif   // HEAP_H
