#include <stdint.h>
/*
 *  $Id: RightOnFullReg.h,v 1.1 1999/11/22 01:57:18 ags-sw Exp $
 */

extern void RightOnFullReg (struct lg_master *pLgMaster,
			    char * parameters,
			    uint32_t respondToWhom );
