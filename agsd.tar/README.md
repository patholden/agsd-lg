# AGS daemon source
