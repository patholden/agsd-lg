#include <stdint.h>
#ifndef TAN_INIT_H
#define TAN_INIT_H

extern double *Xtans;
extern double *Ytans;
extern int    *Yflag;
extern int     gNtanpoly;

extern
void
tan_init( void )
;

#endif
