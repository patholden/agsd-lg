#include <stdint.h>
#ifndef SEGTEST_H
#define SEGTEST_H

int segtest(double x1, double y1, double x2, double y2,
	    double x3, double y3, double x4, double y4,
	    double *x_inter, double *y_inter, double *B_u);

#endif
