#include <stdint.h>
#ifndef PNPOLY_H
#define PNPOLY_H

extern
int
pnpoly( int npol
      , double *xp
      , double *yp
      , double x
      , double y
      )
;

#endif
