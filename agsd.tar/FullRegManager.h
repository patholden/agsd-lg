#ifndef FULLREGMGR_H
#define FULLREGMGR_H

void PerformAndSendFullReg(struct lg_master *pLgMaster, struct lg_xydata *data, uint32_t respondToWhom);

#endif
