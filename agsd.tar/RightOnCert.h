/*
 * $Id: RightOnCert.h,v 1.1 1999/11/22 01:58:11 ags-sw Exp $
 */
#ifndef RTONCRT_H
#define RTONCRT_H

void RightOnCert(struct lg_master *pLgMaster,
		 char *parameters,
		 uint32_t respondToWhom);
#endif  // RTONCRT_H
