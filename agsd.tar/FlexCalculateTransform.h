#ifndef FLEXCALCXFM_H
#define FLEXCALCXFM_H

void FlexCalculateTransform(struct lg_master *pLgMaster, struct parse_flexcalxfrm_parms *pInp, uint32_t respondToWhom);
#endif

