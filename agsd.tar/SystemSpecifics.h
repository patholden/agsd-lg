#ifndef SYSTEMSPEC_H
#define SYSTEMSPEC_H
int32_t SystemGoAhead ( void );
void DoSystemPeriodic (struct lg_master *pLgMaster);

#endif // SYSTEMSPEC_H
