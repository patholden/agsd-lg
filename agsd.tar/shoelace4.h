#include <stdint.h>

#ifndef SHOELACE4_H
#define SHOELACE4_H

extern
double
shoelace4( double *x, double *y )
;

#endif
