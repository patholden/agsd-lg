#ifndef DOCHANGEDISPLAYPERIOD_H
#define DOCHANGEDISPLAYPERIOD_H

void DoChangeDisplayPeriod(struct lg_master *pLgMaster, struct parse_chngdisp_parms* parameters);

#endif
