#include <stdint.h>
#ifndef HEADFLASH_H
#define HEADFLASH_H 1


#defile HEADFLASHSIZE 200

extern int
HeadFlash( unsigned char * buffer, unsigned char * filename, int count );

#endif
