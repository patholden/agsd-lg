#include <stdint.h>
/*   $Id: UserMaint.h,v 1.2 1996/12/25 18:38:04 ags-sw Exp $  */

extern	int32_t	gInitError;
