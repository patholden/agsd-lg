extern void FullRegWithFeedback (struct lg_master *pLgMaster,
				 char * parameters,
				 uint32_t respondToWhom);
