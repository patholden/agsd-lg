#ifndef CALCTRNSFM_H
#define CALCTRNSFM_H
void CalculateTransform(struct lg_master *pLgMaster,struct parse_clcxfrm_parms * pInp,
			uint32_t respondToWhom);
#endif  // CALCTRNSFM_H
