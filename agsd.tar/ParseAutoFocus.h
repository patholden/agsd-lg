#ifndef PARSEAF_H
#define PARSEAF_H

int ParseAutoFocus(int length, char * infile);
#endif
