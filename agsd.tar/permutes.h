#include <stdint.h>

#ifndef PERMUTES_H
#define PERMUTES_H

typedef struct
{
                 int index1;
                 int index2;
                 int index3;
                 int index4;
                 double area;
} permutes;   

#endif
