#ifndef DOFINDTGT_H
#define DOFINDTGT_H
/*
 *  $Id$
 */

void DoFindOneTarget(struct lg_master *pLgMaster, struct parse_findonetgt_parms *pInp,
			     uint32_t respondToWhom);
#endif  // DOFINDTGT_H
