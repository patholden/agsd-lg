#include <stdint.h>
/*
 *   $Id: Web.h,v 1.1 2000/07/11 21:53:50 ags-sw Exp $
 */


extern int GetWebVideo(struct lg_master *pLgMaster, char *inbuff, int incount, char *outbuff);

